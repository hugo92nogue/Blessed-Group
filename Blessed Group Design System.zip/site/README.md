# Blessed Group — Sitio Web (listo para desplegar)

Sitio estático de una sola página. **No requiere build** — es HTML/CSS/JS que
corre en el navegador. Funciona en cualquier hosting estático (GitHub Pages,
Vercel, Render, Netlify…).

## Estructura
```
index.html        ← página principal
styles.css        ← estilos (importa tokens/)
tokens/           ← variables de color, tipografía, espaciado
_ds_bundle.js     ← componentes del sistema de diseño (Blessed Group)
data.js           ← TODO el contenido (textos, imágenes) — editá acá
icons.jsx         ← iconos
parts1.jsx        ← Header, Hero, Nosotros, Stats, Servicios
parts2.jsx        ← Proceso, Proyectos, Blog, CTA, Contacto, Footer
assets/           ← logo
render.yaml       ← config para Render
vercel.json       ← config para Vercel
```

## Probar localmente
Abrí `index.html` con un servidor estático (no con doble clic, por el CORS de los `.jsx`):
```bash
npx serve .
# o
python3 -m http.server 8080
```
Luego entrá a `http://localhost:8080`.

---

## 1) Subir a GitHub
```bash
cd site
git init
git add .
git commit -m "Blessed Group — sitio web"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/blessed-group-web.git
git push -u origin main
```
(Creá antes el repo vacío `blessed-group-web` en github.com.)

## 2) Desplegar en Vercel
1. Entrá a https://vercel.com → **Add New… → Project**.
2. Importá el repo `blessed-group-web`.
3. Framework Preset: **Other**. Build Command: vacío. Output Directory: `.` (raíz).
4. **Deploy**. Listo — Vercel te da la URL.

## 3) Desplegar en Render
1. Entrá a https://render.com → **New → Static Site**.
2. Conectá el repo `blessed-group-web`.
3. Build Command: *(vacío)*. Publish Directory: `.` (raíz).
4. **Create Static Site**. (El `render.yaml` ya trae esta config.)

---

## Notas
- Las imágenes de proyectos/hero son de archivo (placeholder). Reemplazalas en
  `data.js` por fotos reales de Blessed Group.
- Teléfono, WhatsApp y dirección son de referencia — confirmá los datos en `data.js`.
- Para producción de alto tráfico conviene precompilar el JSX (hoy se transpila en
  el navegador con Babel). Para una landing está perfecto así.
